#!/bin/bash
set -e

# 自动识别多种 CTF 平台的 Flag 变量
if [ -n "$A1CTF_FLAG" ]; then
    export FLAG="$A1CTF_FLAG"
elif [ -n "$GZCTF_FLAG" ]; then
    export FLAG="$GZCTF_FLAG"
elif [ -n "$QUESTION_CTF_FLAG" ]; then
    export FLAG="$QUESTION_CTF_FLAG"
else
    export FLAG="VNCTF{!!!!_FLAG_ERROR_ASK_ADMIN_!!!!}"
fi

# 写入文件并保护
echo $FLAG > /flag
chmod 444 /flag

echo "[*] Flag initialized."
echo "[*] Launching Web Server..."

# 启动 Python
exec python3 app.py