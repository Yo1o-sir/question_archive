from flask import Flask, render_template, request, jsonify
import os
import time

app = Flask(__name__)

# 配置题目和答案
CHALLENGES = [
    {"id": 1, "q": "Vshell 的 stage1 文件名是什么?(e.g. app)", "a": "gift"},
    {"id": 2, "q": "监听机器的IP与端口是什么?(e.g. 127.0.0.1:1234)", "a": "192.168.56.1:11451"},
    {"id": 3, "q": "流量加密时的 Salt 是什么?(e.g. qwe123qwe)", "a": "It_is_my_secret!!!"},
    {"id": 4, "q": "桌面的压缩包密码是什么?(e.g. qwe123)", "a": "White_hat"},
    {"id": 5, "q": "VIP_file 的内容是什么?(e.g. welcometoctf)", "a": "Welcome to the V&N family"}
]

def get_flag():
    if os.path.exists('/flag'):
        with open('/flag', 'r') as f:
            return f.read().strip()
    return "VNCTF{!!!!_FLAG_ERROR_ASK_ADMIN_!!!!}"

@app.route('/')
def index():
    return render_template('index.html', challenges=CHALLENGES)

@app.route('/verify', methods=['POST'])
def verify():
    # --- 防爆破策略 ---
    # 强制让每个请求处理时间至少为 1.5 秒
    time.sleep(1.5) 
    
    data = request.json
    step = data.get('step')
    answer = data.get('answer', '').strip()
    
    if 1 <= step <= len(CHALLENGES):
        if answer == CHALLENGES[step-1]['a']:
            res = {"success": True}
            if step == len(CHALLENGES):
                res["flag"] = get_flag()
            return jsonify(res)
    
    return jsonify({"success": False, "msg": "ACCESS DENIED: Invalid Decryption Key"})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)